const readCsvData = () => {
    axios.post('/list', {
        file: 'oida',
        lastName: 'Flintstone'
      })
      .then((response) => {
        const data = response.data;
        let $csvList = document.querySelector("#csv-list");
        data.forEach((e, idx) => {
            const li = document.createElement('li');
            li.textContent = e;
            li.id = "list" + idx;
            li.onclick = () => getCsvFile(e, idx);
            $csvList.appendChild(li)
        })
        console.log(data)
      })
      .catch(function (error) {
        console.log(error);
      });
}

const getCsvFile = (name, idx) => {
    console.log(name)
    const url = "/file";
    axios.post(url, {
        file: name
    })
    .then((response) => {
        document.querySelector("#raw").textContent = response.data;
        redrawPlot(response.data);
    })
}

const redrawPlot = (data) => {
    console.log("PLOT ME");
    console.log(data);
    // TODO here you can redraw your plot with data
}