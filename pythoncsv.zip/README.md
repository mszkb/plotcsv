# infovis_ue_3

## Install

```
pip3 install -r requirements.txt
python3 app.py
```